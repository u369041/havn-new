// /public_html/config.js
// Plain JavaScript (no <script> tags)
window.HAVN_CONFIG = {
  API_BASE: "https://api.havn.ie",
  GMAPS_API_KEY: "AIzaSyDYbJS_6BbhnLlb3W0KZYk5vk6KrTqhyUc"
};
