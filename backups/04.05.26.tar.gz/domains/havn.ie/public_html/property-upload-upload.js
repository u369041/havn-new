/* property-upload-upload.js
   Upload + Cloudinary signature module ONLY
   Safe, minimal, no UI assumptions
*/

(function () {
  const API = "https://api.havn.ie";

  // exposed state hook (HTML owns PHOTOS array)
  window.HAVN_UPLOADS = {
    async uploadFiles(files, onUrl, onError, onStatus) {
      try {
        if (!files || !files.length) return;

        onStatus && onStatus("signature:fetching");

        const sig = await getSignature();
        assertSignature(sig);

        onStatus && onStatus("upload:starting");

        for (const file of files) {
          const url = await uploadOne(file, sig);
          if (url) onUrl && onUrl(url);
        }

        onStatus && onStatus("upload:done");
      } catch (err) {
        onStatus && onStatus("upload:error");
        onError && onError(err);
      }
    }
  };

  async function getSignature() {
    const res = await apiFetch("/api/uploads/cloudinary-signature", {
      method: "POST"
    });

    const text = await res.text();
    if (!res.ok) {
      throw new Error(
        Signature fetch failed (${res.status})\n${text}
      );
    }

    let json;
    try {
      json = JSON.parse(text);
    } catch {
      throw new Error("Signature response was not JSON");
    }

    return {
      cloudName: json.cloudName || json.cloud_name,
      apiKey: json.apiKey || json.api_key,
      timestamp: json.timestamp,
      signature: json.signature,
      folder: json.folder || null,
      uploadPreset: json.uploadPreset || json.upload_preset || null
    };
  }

  function assertSignature(s) {
    const missing = [];
    if (!s.cloudName) missing.push("cloudName");
    if (!s.apiKey) missing.push("apiKey");
    if (!s.timestamp) missing.push("timestamp");
    if (!s.signature) missing.push("signature");

    if (missing.length) {
      throw new Error(
        "Signature missing fields: " + missing.join(", ")
      );
    }
  }

  async function uploadOne(file, sig) {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("api_key", sig.apiKey);
    fd.append("timestamp", String(sig.timestamp));
    fd.append("signature", sig.signature);

    // IMPORTANT: only params that were signed
    if (sig.folder) fd.append("folder", sig.folder);
    if (sig.uploadPreset) fd.append("upload_preset", sig.uploadPreset);

    const url =
      "https://api.cloudinary.com/v1_1/" +
      encodeURIComponent(sig.cloudName) +
      "/auto/upload";

    const res = await fetch(url, { method: "POST", body: fd });
    const json = await res.json().catch(() => null);

    if (!res.ok || !json) {
      throw new Error(
        Cloudinary upload failed (${res.status})\n +
        JSON.stringify(json || {}, null, 2)
      );
    }

    return json.secure_url || json.url;
  }

  async function apiFetch(path, opts) {
    if (window.HAVN_AUTH && typeof HAVN_AUTH.apiFetch === "function") {
      return HAVN_AUTH.apiFetch(API + path, opts);
    }

    const token = localStorage.getItem("token");
    const headers = Object.assign(
      { "Content-Type": "application/json" },
      opts.headers || {},
      token ? { Authorization: "Bearer " + token } : {}
    );

    return fetch(API + path, Object.assign({}, opts, { headers }));
  }
})();