/* latest-properties.js — homepage loader + engagement sections
   - Keeps mode-correct BUY / RENT / SHARE latest listings
   - Adds homepage Saved Homes section
   - Adds homepage Recently Viewed section
   - Supports Featured listings first
   - Uses same localStorage keys as property.html
   - Minimal-change
   - HARD RULE: only PUBLISHED listings can appear anywhere on homepage
*/

(function(){
  "use strict";

  const API = "https://api.havn.ie";
  const STORAGE_RECENT = "havn_recent_properties_v1";
  const STORAGE_SAVED = "havn_saved_properties_v1";

  function $(sel, root){ return (root || document).querySelector(sel); }
  function esc(s){ return String(s || "").replace(/[&<>"']/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]); }); }

  function safeReadJson(key){
    try{
      const raw = localStorage.getItem(key);
      if(!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    }catch{
      return [];
    }
  }

  function safeWriteJson(key, value){
    try{
      localStorage.setItem(key, JSON.stringify(Array.isArray(value) ? value : []));
    }catch{}
  }

  function normalizeStatus(value){
    return String(value || "").trim().toUpperCase();
  }

  function getSlug(p){
    return String((p && p.slug) || "").trim().toLowerCase();
  }

  function isPublished(p){
    if(!p) return false;
    const status = normalizeStatus(p.listingStatus || p.status || p.publicStatus || "");
    return status === "PUBLISHED";
  }

  function hasActiveFeature(p){
    if(!p || !p.isFeatured) return false;

    const raw = p.featuredUntil;
    if(!raw) return true;

    const d = new Date(raw);
    if(String(d) === "Invalid Date") return true;

    return d.getTime() > Date.now();
  }

  function sortFeaturedFirst(items){
    return (Array.isArray(items) ? items : []).slice().sort(function(a, b){
      const af = hasActiveFeature(a) ? 1 : 0;
      const bf = hasActiveFeature(b) ? 1 : 0;

      if(af !== bf) return bf - af;

      const ap = a && a.publishedAt ? new Date(a.publishedAt).getTime() : 0;
      const bp = b && b.publishedAt ? new Date(b.publishedAt).getTime() : 0;

      if(Number.isFinite(ap) && Number.isFinite(bp) && ap !== bp) return bp - ap;

      const au = a && a.updatedAt ? new Date(a.updatedAt).getTime() : 0;
      const bu = b && b.updatedAt ? new Date(b.updatedAt).getTime() : 0;

      return (Number.isFinite(bu) ? bu : 0) - (Number.isFinite(au) ? au : 0);
    });
  }

  function isRenderablePublicListing(p){
    if(!isPublished(p)) return false;

    const slug = getSlug(p);
    if(!slug) return false;

    const title = String(p.title || "").trim();
    if(!title) return false;
    if(title.toLowerCase() === "untitled listing") return false;

    return true;
  }

  function pickCover(p){
    const arr = p.images || p.imageUrls || p.photos || p.pictures || [];
    if (Array.isArray(arr) && arr.length){
      const first = arr[0];
      if (typeof first === "string") return first;
      if (first && typeof first === "object") return first.url || first.secure_url || first.src || "";
    }
    return p.cover || "";
  }

  function euro(n){
    const num = Number(n);
    if(!Number.isFinite(num) || num <= 0) return "";
    return "€" + num.toLocaleString("en-IE");
  }

  function cardHTML(p, opts){
    if(!isRenderablePublicListing(p)) return "";

    opts = opts || {};
    const compact = !!opts.compact;
    const featured = hasActiveFeature(p);

    const cover = pickCover(p);
    const slug = p.slug || "";
    const title = p.title || p.address || slug || "Property";
    const price = (p.price != null && p.price !== "") ? (euro(p.price) || ("€" + esc(p.price))) : "";
    const meta = [p.county, p.city].filter(Boolean).join(", ");

    const chips = [];
    if (p.price) chips.push(euro(p.price));
    if (p.bedrooms != null && p.bedrooms !== "") chips.push(String(p.bedrooms) + " bed");
    if (p.bathrooms != null && p.bathrooms !== "") chips.push(String(p.bathrooms) + " bath");
    if (p.propertyType) chips.push(String(p.propertyType));

    const featuredBadge = featured
      ? `<span style="position:absolute;top:10px;left:10px;z-index:2;font-size:11px;font-weight:1000;letter-spacing:.01em;border:1px solid rgba(245,158,11,.35);background:rgba(255,251,235,.96);color:#92400e;padding:5px 8px;border-radius:999px;box-shadow:0 8px 18px rgba(15,23,42,.12);">Featured</span>`
      : "";

    if(compact){
      return `
        <a href="/property.html?slug=${encodeURIComponent(slug)}" style="text-decoration:none;color:inherit;display:block;">
          <div style="border:1px solid ${featured ? 'rgba(245,158,11,.28)' : 'rgba(15,23,42,.08)'};background:#fff;border-radius:18px;overflow:hidden;box-shadow:${featured ? '0 16px 34px rgba(245,158,11,.14), 0 12px 30px rgba(15,23,42,.08)' : '0 12px 30px rgba(15,23,42,.08)'};position:relative;">
            ${featuredBadge}
            ${cover ? `<img src="${esc(cover)}" style="width:100%;height:170px;object-fit:cover;display:block;" alt="">` : `<div style="width:100%;height:170px;background:#e5e7eb;"></div>`}
            <div style="padding:12px;">
              <div style="font-weight:1000;margin-bottom:6px;font-size:15px;">${esc(price)}</div>
              <div style="font-weight:1000;line-height:1.25;margin-bottom:6px;">${esc(title)}</div>
              <div style="color:#64748b;font-weight:800;font-size:12px;margin-bottom:10px;">${esc(meta)}</div>
              <div style="display:flex;gap:6px;flex-wrap:wrap;">
                ${chips.map(function(x){ return `<span style="font-size:11px;font-weight:900;border:1px solid #e5e7eb;padding:4px 8px;border-radius:999px;background:#fff;">${esc(x)}</span>`; }).join("")}
              </div>
            </div>
          </div>
        </a>
      `;
    }

    return `
      <a href="/property.html?slug=${encodeURIComponent(slug)}" style="text-decoration:none;color:inherit;">
        <div style="border:1px solid ${featured ? 'rgba(245,158,11,.28)' : 'rgba(15,23,42,.08)'};background:#fff;border-radius:18px;overflow:hidden;box-shadow:${featured ? '0 16px 34px rgba(245,158,11,.14), 0 12px 30px rgba(15,23,42,.08)' : '0 12px 30px rgba(15,23,42,.08)'};width:270px;position:relative;">
          ${featuredBadge}
          ${cover ? `<img src="${esc(cover)}" style="width:100%;height:150px;object-fit:cover;display:block;" alt="">` : `<div style="width:100%;height:150px;background:#e5e7eb;"></div>`}
          <div style="padding:12px 12px 14px;">
            <div style="font-weight:1000;margin-bottom:6px;">${esc(price)}</div>
            <div style="font-weight:1000;line-height:1.2;">${esc(title)}</div>
            <div style="margin-top:6px;color:#64748b;font-weight:800;font-size:12px;">${esc(meta)}</div>
            <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap;">
              ${chips.map(function(x){ return `<span style="font-size:11px;font-weight:900;border:1px solid #e5e7eb;padding:4px 8px;border-radius:999px;background:#fff;">${esc(x)}</span>`; }).join("")}
            </div>
          </div>
        </div>
      </a>
    `;
  }

  async function fetchMode(mode){
    const url = API + "/api/properties?mode=" + encodeURIComponent(mode);
    const r = await fetch(url, { headers: { "Accept":"application/json" } });
    const t = await r.text().catch(function(){ return ""; });
    let j = null;
    try{ j = t ? JSON.parse(t) : null; }catch{}
    if(!r.ok) throw new Error("HTTP " + r.status + " " + url + "\n" + t);
    const items = (j && (j.items || j.properties || j.data)) ? (j.items || j.properties || j.data) : [];
    return Array.isArray(items) ? sortFeaturedFirst(items.filter(isRenderablePublicListing)) : [];
  }

  function renderCards(items, mountSel){
    const mount = $(mountSel);
    if(!mount) return;

    const published = sortFeaturedFirst((Array.isArray(items) ? items : []).filter(isRenderablePublicListing));

    if(!published.length){
      mount.innerHTML = `<div style="padding:14px;color:#64748b;font-weight:800;">No published listings yet.</div>`;
      return;
    }

    mount.innerHTML = published.map(function(p){ return cardHTML(p); }).filter(Boolean).join("");
  }

  function ensureHomepageEngagementSections(){
    let host = document.getElementById("havn-home-engagement-sections");
    if(host) return host;

    const wrap =
      $("#latestShare")?.closest("section, .panel, .wrap, main, .container") ||
      $("#latestRent")?.closest("section, .panel, .wrap, main, .container") ||
      $("#latestBuy")?.closest("section, .panel, .wrap, main, .container") ||
      document.querySelector("main") ||
      document.querySelector(".wrap") ||
      document.body;

    host = document.createElement("div");
    host.id = "havn-home-engagement-sections";
    host.style.marginTop = "22px";

    host.innerHTML = `
      <section style="margin-top:18px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
          <h2 style="margin:0;font-size:20px;font-weight:1000;letter-spacing:-0.02em;color:#0f172a;">Saved homes</h2>
          <a href="/properties.html" style="text-decoration:none;font-size:12px;font-weight:900;color:#2563eb;">Browse more</a>
        </div>
        <div id="homeSavedGrid" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;"></div>
        <div id="homeSavedEmpty" style="display:none;padding:14px;color:#64748b;font-weight:800;border:1px dashed rgba(15,23,42,.10);border-radius:16px;background:rgba(246,248,252,.75);">Saved properties will appear here when you tap “Save property”.</div>
      </section>

      <section style="margin-top:18px;">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:10px;">
          <h2 style="margin:0;font-size:20px;font-weight:1000;letter-spacing:-0.02em;color:#0f172a;">Recently viewed</h2>
          <a href="/properties.html" style="text-decoration:none;font-size:12px;font-weight:900;color:#2563eb;">Continue browsing</a>
        </div>
        <div id="homeRecentGrid" style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;"></div>
        <div id="homeRecentEmpty" style="display:none;padding:14px;color:#64748b;font-weight:800;border:1px dashed rgba(15,23,42,.10);border-radius:16px;background:rgba(246,248,252,.75);">Recently viewed properties will appear here as you browse HAVN.</div>
      </section>
    `;

    if(wrap === document.body){
      document.body.appendChild(host);
    }else{
      wrap.appendChild(host);
    }

    if(!document.getElementById("havn-home-engagement-style")){
      const st = document.createElement("style");
      st.id = "havn-home-engagement-style";
      st.textContent = `
        @media (max-width: 980px){
          #homeSavedGrid, #homeRecentGrid{
            grid-template-columns: repeat(2, minmax(0,1fr)) !important;
          }
        }
        @media (max-width: 680px){
          #homeSavedGrid, #homeRecentGrid{
            grid-template-columns: 1fr !important;
          }
        }
      `;
      document.head.appendChild(st);
    }

    return host;
  }

  async function fetchAllPublishedLookup(){
    const modeResults = await Promise.allSettled([
      fetchMode("BUY"),
      fetchMode("RENT"),
      fetchMode("SHARE")
    ]);

    const map = new Map();

    modeResults.forEach(function(result){
      if(result.status !== "fulfilled") return;
      const items = Array.isArray(result.value) ? result.value : [];
      items.forEach(function(item){
        const slug = getSlug(item);
        if(!slug) return;
        if(!isRenderablePublicListing(item)) return;
        if(!map.has(slug)){
          map.set(slug, item);
        }
      });
    });

    return map;
  }

  function cleanupStoredItems(storedItems, publishedLookup){
    const arr = Array.isArray(storedItems) ? storedItems : [];
    const out = [];
    const seen = new Set();

    arr.forEach(function(item){
      const slug = getSlug(item);
      if(!slug) return;
      if(seen.has(slug)) return;

      const live = publishedLookup.get(slug);
      if(!live) return;
      if(!isRenderablePublicListing(live)) return;

      seen.add(slug);
      out.push(live);
    });

    return sortFeaturedFirst(out).slice(0, 6);
  }

  async function renderSavedHomes(publishedLookup){
    ensureHomepageEngagementSections();

    const grid = $("#homeSavedGrid");
    const empty = $("#homeSavedEmpty");
    if(!grid || !empty) return;

    const stored = safeReadJson(STORAGE_SAVED);
    const items = cleanupStoredItems(stored, publishedLookup);
    safeWriteJson(STORAGE_SAVED, items);

    if(!items.length){
      grid.innerHTML = "";
      empty.style.display = "block";
      return;
    }

    empty.style.display = "none";
    grid.innerHTML = items.map(function(p){ return cardHTML(p, { compact:true }); }).filter(Boolean).join("");
  }

  async function renderRecentlyViewed(publishedLookup){
    ensureHomepageEngagementSections();

    const grid = $("#homeRecentGrid");
    const empty = $("#homeRecentEmpty");
    if(!grid || !empty) return;

    const stored = safeReadJson(STORAGE_RECENT);
    const items = cleanupStoredItems(stored, publishedLookup);
    safeWriteJson(STORAGE_RECENT, items);

    if(!items.length){
      grid.innerHTML = "";
      empty.style.display = "block";
      return;
    }

    empty.style.display = "none";
    grid.innerHTML = items.map(function(p){ return cardHTML(p, { compact:true }); }).filter(Boolean).join("");
  }

  async function loadAll(){
    const mounts = {
      BUY:  "#latestBuy",
      RENT: "#latestRent",
      SHARE:"#latestShare"
    };

    try{
      const [buy, rent, share, publishedLookup] = await Promise.all([
        fetchMode("BUY"),
        fetchMode("RENT"),
        fetchMode("SHARE"),
        fetchAllPublishedLookup()
      ]);

      renderCards(buy, mounts.BUY);
      renderCards(rent, mounts.RENT);
      renderCards(share, mounts.SHARE);

      await renderSavedHomes(publishedLookup);
      await renderRecentlyViewed(publishedLookup);

      console.log("latest-properties loaded:", {
        buy: buy.length,
        rent: rent.length,
        share: share.length,
        featuredBuy: buy.filter(hasActiveFeature).length,
        featuredRent: rent.filter(hasActiveFeature).length,
        featuredShare: share.filter(hasActiveFeature).length,
        saved: safeReadJson(STORAGE_SAVED).length,
        recent: safeReadJson(STORAGE_RECENT).length
      });
    }catch(e){
      console.error(e);

      try{
        const publishedLookup = await fetchAllPublishedLookup();
        await renderSavedHomes(publishedLookup);
        await renderRecentlyViewed(publishedLookup);
      }catch(inner){
        console.error(inner);
      }
    }
  }

  document.addEventListener("DOMContentLoaded", loadAll);
})();