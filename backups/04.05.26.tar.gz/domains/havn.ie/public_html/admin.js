/* admin.js — HAVN.ie admin dashboard
   Minimal-change, defensive implementation.
   - Save        => PATCH /api/admin/properties/:id
   - Approve     => POST  /api/admin/properties/:id/approve
   - Reject      => POST  /api/admin/properties/:id/reject
   - Close       => POST  /api/admin/properties/:id/close
   - Reopen      => POST  /api/admin/properties/:id/reopen
   - Feature     => POST  /api/admin/properties/:id/feature
   - Unfeature   => POST  /api/admin/properties/:id/unfeature
   - Listings    => GET   /api/properties/_admin
   - Enquiries   => GET   /api/properties/_admin/enquiries
   - Enquiry edit=> PATCH /api/properties/_admin/enquiries/:id

   UI rules:
   - Approve/Reject only show for SUBMITTED listings
   - CLOSED listings show Reopen
   - PUBLISHED listings can be Featured / Unfeatured
   - All non-CLOSED listings show Close
*/

(function () {
  "use strict";

  const API_BASE = "https://api.havn.ie";

  const state = {
    listings: [],
    enquiries: [],
    loadingListings: false,
    loadingEnquiries: false,
    currentFilter: "ALL",
    searchTerm: "",
  };

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    try {
      await ensureAdminAuth();
      bindStaticUI();
      await Promise.all([loadListings(), loadEnquiries()]);
    } catch (err) {
      console.error("Admin init failed:", err);
      showTopMessage(errorMessage(err), "error");
    }
  }

  async function ensureAdminAuth() {
    try {
      if (window.HAVN_AUTH && typeof window.HAVN_AUTH.requireAuth === "function") {
        await window.HAVN_AUTH.requireAuth();
      }
    } catch (err) {
      console.warn("HAVN_AUTH.requireAuth failed:", err);
    }
  }

  function bindStaticUI() {
    const refreshBtn =
      $("#refreshBtn") ||
      $("#reloadBtn") ||
      $('[data-action="refresh"]');

    if (refreshBtn) {
      refreshBtn.addEventListener("click", async function () {
        await Promise.all([loadListings(), loadEnquiries()]);
      });
    }

    const searchInput =
      $("#listingSearch") ||
      $("#searchListings") ||
      $("#adminSearch") ||
      $('input[type="search"]');

    if (searchInput) {
      searchInput.addEventListener("input", function (e) {
        state.searchTerm = String(e.target.value || "").trim().toLowerCase();
        renderListings();
      });
    }

    const filterButtons = $all("[data-filter]");
    if (filterButtons.length) {
      filterButtons.forEach(function (btn) {
        btn.addEventListener("click", function () {
          state.currentFilter = String(btn.getAttribute("data-filter") || "ALL").toUpperCase();
          filterButtons.forEach(function (b) { b.classList.remove("active"); });
          btn.classList.add("active");
          renderListings();
        });
      });
    }

    const listingsWrap = getListingsWrap();
    if (listingsWrap) {
      listingsWrap.addEventListener("click", onListingsClick);
      listingsWrap.addEventListener("change", onListingsChange);
      listingsWrap.addEventListener("submit", onListingsSubmit);
    }

    const enquiriesWrap = getEnquiriesWrap();
    if (enquiriesWrap) {
      enquiriesWrap.addEventListener("click", onEnquiriesClick);
      enquiriesWrap.addEventListener("change", onEnquiriesChange);
      enquiriesWrap.addEventListener("submit", onEnquiriesSubmit);
    }
  }

  async function loadListings() {
    state.loadingListings = true;
    setSectionLoading("listings", true);

    try {
      const res = await apiFetchResponse("/api/properties/_admin", { method: "GET" });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to load listings");
      }

      state.listings = normalizeListings(json);
      updateSummary(state.listings, state.enquiries);
      renderListings();
    } catch (err) {
      console.error("loadListings failed:", err);
      renderListingsError(errorMessage(err));
      showTopMessage(errorMessage(err), "error");
    } finally {
      state.loadingListings = false;
      setSectionLoading("listings", false);
    }
  }

  async function loadEnquiries() {
    state.loadingEnquiries = true;
    setSectionLoading("enquiries", true);

    try {
      const res = await apiFetchResponse("/api/properties/_admin/enquiries", { method: "GET" });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to load enquiries");
      }

      state.enquiries = normalizeEnquiries(json);
      updateSummary(state.listings, state.enquiries);
      renderEnquiries();
    } catch (err) {
      console.error("loadEnquiries failed:", err);
      renderEnquiriesError(errorMessage(err));
      showTopMessage(errorMessage(err), "error");
    } finally {
      state.loadingEnquiries = false;
      setSectionLoading("enquiries", false);
    }
  }

  function onListingsClick(e) {
    const btn = e.target.closest("button");
    if (!btn) return;

    const action = String(btn.getAttribute("data-action") || "");
    const id = btn.getAttribute("data-id");
    if (!id) return;

    if (action === "approve") {
      e.preventDefault();
      approveListing(id, btn);
      return;
    }

    if (action === "reject") {
      e.preventDefault();
      rejectListing(id, btn);
      return;
    }

    if (action === "save") {
      e.preventDefault();
      saveListing(id, btn);
      return;
    }

    if (action === "close") {
      e.preventDefault();
      closeListing(id, btn);
      return;
    }

    if (action === "reopen") {
      e.preventDefault();
      reopenListing(id, btn);
      return;
    }

    if (action === "feature") {
      e.preventDefault();
      featureListing(id, btn);
      return;
    }

    if (action === "unfeature") {
      e.preventDefault();
      unfeatureListing(id, btn);
      return;
    }

    if (action === "toggle-details") {
      e.preventDefault();
      const card = btn.closest("[data-listing-id]");
      if (!card) return;
      const panel = card.querySelector(".admin-listing-details");
      if (!panel) return;
      const isHidden = panel.hasAttribute("hidden");
      if (isHidden) {
        panel.removeAttribute("hidden");
        btn.textContent = "Hide";
      } else {
        panel.setAttribute("hidden", "");
        btn.textContent = "Manage";
      }
      return;
    }
  }

  function onListingsChange(e) {
    const el = e.target;
    const card = el.closest("[data-listing-id]");
    if (!card) return;

    if (el.matches('[data-field="listingStatus"]')) {
      card.setAttribute("data-dirty", "true");
    }

    if (el.matches('[data-field="adminNote"]')) {
      card.setAttribute("data-dirty", "true");
    }
  }

  function onListingsSubmit(e) {
    const form = e.target.closest("form[data-role='listing-form']");
    if (!form) return;
    e.preventDefault();

    const btn = form.querySelector('button[data-action="save"]');
    const id = form.getAttribute("data-id");
    if (!id || !btn) return;

    saveListing(id, btn);
  }

  function onEnquiriesClick(e) {
    const btn = e.target.closest("button");
    if (!btn) return;

    const action = String(btn.getAttribute("data-action") || "");
    const id = btn.getAttribute("data-id");
    if (!id) return;

    if (action === "save-enquiry") {
      e.preventDefault();
      saveEnquiry(id, btn);
    }
  }

  function onEnquiriesChange(e) {
    const row = e.target.closest("[data-enquiry-id]");
    if (!row) return;
    row.setAttribute("data-dirty", "true");
  }

  function onEnquiriesSubmit(e) {
    const form = e.target.closest("form[data-role='enquiry-form']");
    if (!form) return;
    e.preventDefault();

    const btn = form.querySelector('button[data-action="save-enquiry"]');
    const id = form.getAttribute("data-id");
    if (!id || !btn) return;

    saveEnquiry(id, btn);
  }

  async function saveListing(id, btn) {
    const card = getListingCard(id);
    if (!card) return;

    const payload = {
      listingStatus: valueOf(card, '[data-field="listingStatus"]'),
      adminNote: valueOf(card, '[data-field="adminNote"]'),
    };

    if (payload.adminNote == null) delete payload.adminNote;

    try {
      setButtonLoading(btn, true, "Saving...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}`, {
        method: "PATCH",
        body: JSON.stringify(payload),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to save listing");
      }

      showTopMessage("Listing saved.", "success");
      await loadListings();
    } catch (err) {
      console.error("saveListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function approveListing(id, btn) {
    const card = getListingCard(id);
    if (!card) return;

    const currentStatus = normalizedStatus(valueOf(card, '[data-field="listingStatus"]') || card.getAttribute("data-status"));
    if (currentStatus !== "SUBMITTED") {
      showTopMessage("Only SUBMITTED listings can be approved.", "error");
      return;
    }

    const adminNote = valueOf(card, '[data-field="adminNote"]');

    try {
      setButtonLoading(btn, true, "Approving...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/approve`, {
        method: "POST",
        body: JSON.stringify(adminNote ? { adminNote } : {}),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to approve listing");
      }

      showTopMessage("Listing approved.", "success");
      await loadListings();
    } catch (err) {
      console.error("approveListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function rejectListing(id, btn) {
    const card = getListingCard(id);
    if (!card) return;

    const currentStatus = normalizedStatus(valueOf(card, '[data-field="listingStatus"]') || card.getAttribute("data-status"));
    if (currentStatus !== "SUBMITTED") {
      showTopMessage("Only SUBMITTED listings can be rejected.", "error");
      return;
    }

    const adminNote = valueOf(card, '[data-field="adminNote"]');

    try {
      setButtonLoading(btn, true, "Rejecting...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/reject`, {
        method: "POST",
        body: JSON.stringify(adminNote ? { reason: adminNote, adminNote } : {}),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to reject listing");
      }

      showTopMessage("Listing rejected.", "success");
      await loadListings();
    } catch (err) {
      console.error("rejectListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function closeListing(id, btn) {
    const card = getListingCard(id);
    if (!card) return;

    const currentStatus = normalizedStatus(card.getAttribute("data-status"));
    if (currentStatus !== "PUBLISHED") {
      showTopMessage("Only PUBLISHED listings can be closed.", "error");
      return;
    }

    const rawOutcome = window.prompt("Close listing as SOLD, RENTED, CANCELLED or OTHER?", "SOLD");
    if (rawOutcome === null) return;

    const outcome = String(rawOutcome || "").trim().toUpperCase();
    if (!["SOLD", "RENTED", "CANCELLED", "OTHER"].includes(outcome)) {
      showTopMessage("Invalid close outcome. Use SOLD, RENTED, CANCELLED or OTHER.", "error");
      return;
    }

    try {
      setButtonLoading(btn, true, "Closing...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/close`, {
        method: "POST",
        body: JSON.stringify({ outcome }),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to close listing");
      }

      showTopMessage("Listing closed.", "success");
      await loadListings();
    } catch (err) {
      console.error("closeListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function reopenListing(id, btn) {
    try {
      setButtonLoading(btn, true, "Reopening...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/reopen`, {
        method: "POST",
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to reopen listing");
      }

      showTopMessage("Listing reopened.", "success");
      await loadListings();
    } catch (err) {
      console.error("reopenListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function featureListing(id, btn) {
    const card = getListingCard(id);
    if (!card) return;

    const currentStatus = normalizedStatus(card.getAttribute("data-status"));
    if (currentStatus !== "PUBLISHED") {
      showTopMessage("Only PUBLISHED listings can be featured.", "error");
      return;
    }

    const rawDays = window.prompt("Feature for how many days? Leave blank for no expiry.", "7");
    if (rawDays === null) return;

    let payload = {};
    const daysText = String(rawDays || "").trim();

    if (daysText) {
      const days = Number(daysText);
      if (!Number.isFinite(days) || days <= 0) {
        showTopMessage("Enter a valid number of days, or leave blank.", "error");
        return;
      }

      const until = new Date();
      until.setDate(until.getDate() + Math.round(days));
      payload.featuredUntil = until.toISOString();
    }

    try {
      setButtonLoading(btn, true, "Featuring...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/feature`, {
        method: "POST",
        body: JSON.stringify(payload),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to feature listing");
      }

      showTopMessage("Listing marked as featured.", "success");
      await loadListings();
    } catch (err) {
      console.error("featureListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function unfeatureListing(id, btn) {
    try {
      setButtonLoading(btn, true, "Removing...");
      const res = await apiFetchResponse(`/api/admin/properties/${id}/unfeature`, {
        method: "POST",
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to remove featured status");
      }

      showTopMessage("Featured status removed.", "success");
      await loadListings();
    } catch (err) {
      console.error("unfeatureListing failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  async function saveEnquiry(id, btn) {
    const row = getEnquiryRow(id);
    if (!row) return;

    const payload = {
      status: valueOf(row, '[data-field="status"]'),
      internalNote: valueOf(row, '[data-field="adminNote"]'),
    };

    try {
      setButtonLoading(btn, true, "Saving...");
      const res = await apiFetchResponse(`/api/properties/_admin/enquiries/${id}`, {
        method: "PATCH",
        body: JSON.stringify(payload),
      });
      const json = await readJsonSafe(res);

      if (!res.ok) {
        throw new Error(json.message || "Failed to save enquiry");
      }

      showTopMessage("Enquiry updated.", "success");
      await loadEnquiries();
    } catch (err) {
      console.error("saveEnquiry failed:", err);
      showTopMessage(errorMessage(err), "error");
    } finally {
      setButtonLoading(btn, false);
    }
  }

  function renderListings() {
    const wrap = getListingsWrap();
    if (!wrap) return;

    const list = filteredListings();
    const moderationQueue = list.filter(function (item) {
      const s = normalizedStatus(item.listingStatus || item.status);
      return s === "SUBMITTED";
    });

    updateCountBadges(list, moderationQueue);

    if (!list.length) {
      wrap.innerHTML = `
        <div class="admin-empty-state">
          <p>No listings found.</p>
        </div>
      `;
      return;
    }

    wrap.innerHTML = list.map(renderListingCard).join("");
  }

  function renderEnquiries() {
    const wrap = getEnquiriesWrap();
    if (!wrap) return;

    if (!state.enquiries.length) {
      wrap.innerHTML = `
        <div class="admin-empty-state">
          <p>No enquiries found.</p>
        </div>
      `;
      return;
    }

    wrap.innerHTML = state.enquiries.map(renderEnquiryCard).join("");
  }

  function renderListingsError(message) {
    const wrap = getListingsWrap();
    if (!wrap) return;
    wrap.innerHTML = `<div class="admin-error-state"><p>${escapeHtml(message)}</p></div>`;
  }

  function renderEnquiriesError(message) {
    const wrap = getEnquiriesWrap();
    if (!wrap) return;
    wrap.innerHTML = `<div class="admin-error-state"><p>${escapeHtml(message)}</p></div>`;
  }

  function filteredListings() {
    let list = Array.isArray(state.listings) ? state.listings.slice() : [];

    if (state.currentFilter && state.currentFilter !== "ALL") {
      list = list.filter(function (item) {
        return normalizedStatus(item.listingStatus || item.status) === state.currentFilter;
      });
    }

    if (state.searchTerm) {
      list = list.filter(function (item) {
        const haystack = [
          item.title,
          item.address1,
          item.address2,
          item.addressLine1,
          item.addressLine2,
          item.city,
          item.county,
          item.eircode,
          item.slug,
          item.sellerName,
          item.contactName,
          item.user && item.user.email,
        ]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();

        return haystack.includes(state.searchTerm);
      });
    }

    list.sort(function (a, b) {
      const af = hasActiveFeature(a) ? 1 : 0;
      const bf = hasActiveFeature(b) ? 1 : 0;

      if (af !== bf) return bf - af;

      const ad = new Date(a.updatedAt || a.createdAt || 0).getTime();
      const bd = new Date(b.updatedAt || b.createdAt || 0).getTime();
      return bd - ad;
    });

    return list;
  }

  function renderListingCard(item) {
    const id = item.id;
    const status = normalizedStatus(item.listingStatus || item.status);
    const featured = hasActiveFeature(item);
    const priceText = formatPrice(item.price, item.rentFrequency);
    const location = [item.address1, item.address2, item.addressLine1, item.addressLine2, item.city, item.county, item.eircode]
      .filter(Boolean)
      .join(", ");
    const hero = firstImage(item);
    const beds = item.bedrooms ?? item.beds ?? "—";
    const baths = item.bathrooms ?? item.baths ?? "—";
    const size = formatSize(item.size, item.sizeUnit);
    const created = formatDate(item.createdAt);
    const updated = formatDate(item.updatedAt);
    const featuredUntil = featured ? formatDate(item.featuredUntil) : "—";
    const seller = item.user?.email || item.email || item.contactEmail || "—";
    const adminNote = item.adminNote || item.rejectedReason || "";
    const badgeClass = statusBadgeClass(status);

    const showModerationButtons = status === "SUBMITTED";
    const showFeatureButtons = status === "PUBLISHED";

    const featureButton = showFeatureButtons
      ? featured
        ? `<button type="button" class="btn-secondary" data-action="unfeature" data-id="${escapeAttr(id)}">Unfeature</button>`
        : `<button type="button" class="btn-success" data-action="feature" data-id="${escapeAttr(id)}">Feature</button>`
      : "";

    const closeOrReopenButton = status === "CLOSED"
      ? `<button type="button" class="btn-secondary" data-action="reopen" data-id="${escapeAttr(id)}">Reopen</button>`
      : status === "PUBLISHED"
        ? `<button type="button" class="btn-secondary" data-action="close" data-id="${escapeAttr(id)}">Close</button>`
        : "";

    return `
      <article class="admin-listing-card${featured ? " is-featured" : ""}" data-listing-id="${escapeAttr(id)}" data-status="${escapeAttr(status)}">
        <div class="admin-listing-card-top">
          <div class="admin-listing-image-wrap" style="position:relative;">
            ${
              featured
                ? `<span class="admin-featured-badge" style="position:absolute;top:10px;left:10px;z-index:2;font-size:11px;font-weight:1000;border:1px solid rgba(245,158,11,.35);background:rgba(255,251,235,.96);color:#92400e;padding:5px 8px;border-radius:999px;box-shadow:0 8px 18px rgba(15,23,42,.12);">Featured</span>`
                : ``
            }
            ${
              hero
                ? `<img class="admin-listing-image" src="${escapeAttr(hero)}" alt="${escapeAttr(item.title || "Property image")}">`
                : `<div class="admin-listing-image admin-listing-image--placeholder">No image</div>`
            }
          </div>

          <div class="admin-listing-main">
            <div class="admin-listing-head">
              <div>
                <h3 class="admin-listing-title">${escapeHtml(item.title || "Untitled property")}</h3>
                <p class="admin-listing-location">${escapeHtml(location || "No address yet")}</p>
              </div>
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end;">
                ${featured ? `<span class="admin-badge badge-warning">FEATURED</span>` : ``}
                <span class="admin-badge ${badgeClass}">${escapeHtml(status)}</span>
              </div>
            </div>

            <div class="admin-listing-meta">
              <span><strong>Price:</strong> ${escapeHtml(priceText)}</span>
              <span><strong>Beds:</strong> ${escapeHtml(String(beds))}</span>
              <span><strong>Baths:</strong> ${escapeHtml(String(baths))}</span>
              <span><strong>Size:</strong> ${escapeHtml(size)}</span>
            </div>

            <div class="admin-listing-meta">
              <span><strong>ID:</strong> ${escapeHtml(String(id))}</span>
              <span><strong>Slug:</strong> ${escapeHtml(item.slug || "—")}</span>
              <span><strong>Seller:</strong> ${escapeHtml(seller)}</span>
            </div>

            <div class="admin-listing-meta">
              <span><strong>Created:</strong> ${escapeHtml(created)}</span>
              <span><strong>Updated:</strong> ${escapeHtml(updated)}</span>
              <span><strong>Featured until:</strong> ${escapeHtml(featuredUntil)}</span>
            </div>

            <div class="admin-listing-actions">
              <button type="button" class="btn-secondary" data-action="toggle-details" data-id="${escapeAttr(id)}">Manage</button>
              ${
                showModerationButtons
                  ? `<button type="button" class="btn-success" data-action="approve" data-id="${escapeAttr(id)}">Approve</button>
                     <button type="button" class="btn-danger" data-action="reject" data-id="${escapeAttr(id)}">Reject</button>`
                  : ``
              }
              ${featureButton}
              ${closeOrReopenButton}
            </div>
          </div>
        </div>

        <div class="admin-listing-details" hidden>
          <form data-role="listing-form" data-id="${escapeAttr(id)}">
            <div class="admin-form-row">
              <label>
                <span>Status</span>
                <select data-field="listingStatus">
                  ${renderStatusOptions(status)}
                </select>
              </label>
            </div>

            <div class="admin-form-row">
              <label>
                <span>Admin note</span>
                <textarea data-field="adminNote" rows="4" placeholder="Internal moderation note or rejection reason">${escapeHtml(adminNote)}</textarea>
              </label>
            </div>

            <div class="admin-form-row">
              <button type="submit" class="btn-primary" data-action="save" data-id="${escapeAttr(id)}">Save</button>
            </div>
          </form>
        </div>
      </article>
    `;
  }

  function renderEnquiryCard(item) {
    const id = item.id;
    const name = item.buyerName || item.name || item.fullName || item.contactName || "Unknown";
    const email = item.buyerEmail || item.email || "—";
    const phone = item.buyerPhone || item.phone || "—";
    const message = item.message || item.enquiry || "—";
    const status = String(item.status || "NEW").toUpperCase();
    const propertyTitle =
      item.property?.title ||
      item.propertyTitle ||
      item.listingTitle ||
      "Unknown property";

    const propertyRef =
      item.property?.slug ||
      item.propertySlug ||
      item.propertyId ||
      "—";

    return `
      <article class="admin-enquiry-card" data-enquiry-id="${escapeAttr(id)}">
        <form data-role="enquiry-form" data-id="${escapeAttr(id)}">
          <div class="admin-enquiry-head">
            <h3 class="admin-enquiry-title">${escapeHtml(name)}</h3>
            <span class="admin-badge ${statusBadgeClass(status)}">${escapeHtml(status)}</span>
          </div>

          <div class="admin-enquiry-meta">
            <span><strong>Property:</strong> ${escapeHtml(propertyTitle)}</span>
            <span><strong>Ref:</strong> ${escapeHtml(String(propertyRef))}</span>
          </div>

          <div class="admin-enquiry-meta">
            <span><strong>Email:</strong> ${escapeHtml(email)}</span>
            <span><strong>Phone:</strong> ${escapeHtml(phone)}</span>
            <span><strong>Date:</strong> ${escapeHtml(formatDate(item.createdAt))}</span>
          </div>

          <div class="admin-enquiry-message">
            ${escapeHtml(message)}
          </div>

          <div class="admin-form-row">
            <label>
              <span>Status</span>
              <select data-field="status">
                ${renderEnquiryStatusOptions(status)}
              </select>
            </label>
          </div>

          <div class="admin-form-row">
            <label>
              <span>Admin note</span>
              <textarea data-field="adminNote" rows="3" placeholder="Internal note">${escapeHtml(item.internalNote || item.adminNote || "")}</textarea>
            </label>
          </div>

          <div class="admin-form-row">
            <button type="submit" class="btn-primary" data-action="save-enquiry" data-id="${escapeAttr(id)}">Save</button>
          </div>
        </form>
      </article>
    `;
  }

  function renderStatusOptions(selected) {
    const options = [
      "DRAFT",
      "SUBMITTED",
      "PUBLISHED",
      "REJECTED",
      "CLOSED",
      "ARCHIVED",
    ];

    return options
      .map(function (value) {
        const sel = value === selected ? " selected" : "";
        return `<option value="${value}"${sel}>${value}</option>`;
      })
      .join("");
  }

  function renderEnquiryStatusOptions(selected) {
    const options = ["NEW", "CONTACTED", "VIEWING_BOOKED", "OFFER_IN_PROGRESS", "CLOSED", "ARCHIVED"];

    return options
      .map(function (value) {
        const sel = value === selected ? " selected" : "";
        return `<option value="${value}"${sel}>${value}</option>`;
      })
      .join("");
  }

  function updateSummary(listings, enquiries) {
    const allListings = Array.isArray(listings) ? listings : [];
    const allEnquiries = Array.isArray(enquiries) ? enquiries : [];

    const counts = {
      total: allListings.length,
      submitted: countByStatus(allListings, "SUBMITTED"),
      published: countByStatus(allListings, "PUBLISHED"),
      rejected: countByStatus(allListings, "REJECTED"),
      closed: countByStatus(allListings, "CLOSED"),
      featured: allListings.filter(hasActiveFeature).length,
      enquiries: allEnquiries.length,
    };

    setText(
      ["#totalListings", "#listingsCount", '[data-stat="total-listings"]'],
      String(counts.total)
    );
    setText(
      ["#submittedCount", '[data-stat="submitted"]'],
      String(counts.submitted)
    );
    setText(
      ["#publishedCount", '[data-stat="published"]'],
      String(counts.published)
    );
    setText(
      ["#rejectedCount", '[data-stat="rejected"]'],
      String(counts.rejected)
    );
    setText(
      ["#closedCount", '[data-stat="closed"]'],
      String(counts.closed)
    );
    setText(
      ["#featuredCount", '[data-stat="featured"]'],
      String(counts.featured)
    );
    setText(
      ["#enquiriesCount", '[data-stat="enquiries"]'],
      String(counts.enquiries)
    );
  }

  function updateCountBadges(filtered, moderationQueue) {
    setText(
      ["#visibleListingsCount", '[data-stat="visible-listings"]'],
      String(filtered.length)
    );
    setText(
      ["#moderationQueueCount", '[data-stat="moderation-queue"]'],
      String(moderationQueue.length)
    );
  }

  function countByStatus(arr, status) {
    return arr.filter(function (item) {
      return normalizedStatus(item.listingStatus || item.status) === status;
    }).length;
  }

  async function apiFetchResponse(path, options) {
    const url = absoluteUrl(path);
    const opts = Object.assign(
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      },
      options || {}
    );

    opts.headers = Object.assign(
      {
        "Content-Type": "application/json",
      },
      opts.headers || {}
    );

    if (window.HAVN_AUTH && typeof window.HAVN_AUTH.apiFetch === "function") {
      const result = await window.HAVN_AUTH.apiFetch(url, opts);

      if (isResponseLike(result)) {
        return result;
      }

      return jsonToResponse(result);
    }

    const token = localStorage.getItem("token");
    if (token) {
      opts.headers.Authorization = "Bearer " + token;
    }

    return fetch(url, opts);
  }

  function isResponseLike(obj) {
    return !!obj && typeof obj === "object" && typeof obj.ok === "boolean" && typeof obj.text === "function";
  }

  function jsonToResponse(data) {
    const ok = !!(data && data.ok !== false);
    return new Response(JSON.stringify(data || {}), {
      status: ok ? 200 : 400,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  async function readJsonSafe(res) {
    try {
      const text = await res.text();
      if (!text) return {};
      return JSON.parse(text);
    } catch (err) {
      return {};
    }
  }

  function normalizeListings(json) {
    if (Array.isArray(json)) return json;
    if (Array.isArray(json.items)) return json.items;
    if (Array.isArray(json.properties)) return json.properties;
    if (Array.isArray(json.listings)) return json.listings;
    if (Array.isArray(json.data)) return json.data;
    return [];
  }

  function normalizeEnquiries(json) {
    if (Array.isArray(json)) return json;
    if (Array.isArray(json.items)) return json.items;
    if (Array.isArray(json.enquiries)) return json.enquiries;
    if (Array.isArray(json.data)) return json.data;
    return [];
  }

  function normalizedStatus(value) {
    return String(value || "").trim().toUpperCase();
  }

  function hasActiveFeature(item) {
    if (!item || !item.isFeatured) return false;

    if (!item.featuredUntil) return true;

    const d = new Date(item.featuredUntil);
    if (Number.isNaN(d.getTime())) return true;

    return d.getTime() > Date.now();
  }

  function statusBadgeClass(status) {
    switch (normalizedStatus(status)) {
      case "PUBLISHED":
      case "APPROVED":
      case "CONTACTED":
      case "VIEWING_BOOKED":
      case "OFFER_IN_PROGRESS":
        return "badge-success";
      case "SUBMITTED":
      case "OPEN":
      case "NEW":
        return "badge-warning";
      case "REJECTED":
        return "badge-danger";
      case "CLOSED":
      case "ARCHIVED":
        return "badge-muted";
      default:
        return "badge-default";
    }
  }

  function firstImage(item) {
    if (!item) return "";
    if (Array.isArray(item.images) && item.images.length) {
      const first = item.images[0];
      if (typeof first === "string") return first;
      if (first && typeof first.url === "string") return first.url;
      if (first && typeof first.secure_url === "string") return first.secure_url;
    }
    if (Array.isArray(item.photos) && item.photos.length) {
      const first = item.photos[0];
      if (typeof first === "string") return first;
      if (first && typeof first.url === "string") return first.url;
    }
    if (typeof item.image === "string") return item.image;
    if (typeof item.heroImage === "string") return item.heroImage;
    return "";
  }

  function formatPrice(price, rentFrequency) {
    if (price == null || price === "") return "—";
    const n = Number(price);
    if (!Number.isFinite(n)) return String(price);

    const base = new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0,
    }).format(n);

    if (rentFrequency) {
      return base + " / " + String(rentFrequency).toLowerCase();
    }

    return base;
  }

  function formatSize(size, unit) {
    if (size == null || size === "") return "—";
    return `${size} ${unit || ""}`.trim();
  }

  function formatDate(value) {
    if (!value) return "—";
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return "—";

    try {
      return new Intl.DateTimeFormat("en-IE", {
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      }).format(d);
    } catch (err) {
      return d.toLocaleString();
    }
  }

  function setSectionLoading(section, isLoading) {
    const target =
      section === "listings"
        ? ($("#listingsLoading") || $('[data-loading="listings"]'))
        : ($("#enquiriesLoading") || $('[data-loading="enquiries"]'));

    if (!target) return;
    target.style.display = isLoading ? "" : "none";
  }

  function getListingsWrap() {
    return (
      $("#adminListings") ||
      $("#listingsWrap") ||
      $("#listingsGrid") ||
      $("#moderationQueue") ||
      $('[data-role="admin-listings"]')
    );
  }

  function getEnquiriesWrap() {
    return (
      $("#adminEnquiries") ||
      $("#enquiriesWrap") ||
      $("#recentEnquiries") ||
      $('[data-role="admin-enquiries"]')
    );
  }

  function getListingCard(id) {
    return document.querySelector(`[data-listing-id="${cssEscape(String(id))}"]`);
  }

  function getEnquiryRow(id) {
    return document.querySelector(`[data-enquiry-id="${cssEscape(String(id))}"]`);
  }

  function valueOf(root, selector) {
    if (!root) return "";
    const el = root.querySelector(selector);
    if (!el) return "";
    return String(el.value || "").trim();
  }

  function setButtonLoading(btn, isLoading, loadingText) {
    if (!btn) return;

    if (isLoading) {
      btn.dataset.originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = loadingText || "Saving...";
      btn.setAttribute("aria-busy", "true");
      return;
    }

    btn.disabled = false;
    btn.textContent = btn.dataset.originalText || btn.textContent || "Save";
    btn.removeAttribute("aria-busy");
  }

  function showTopMessage(message, type) {
    const box =
      $("#adminMessage") ||
      $("#topMessage") ||
      $('[data-role="admin-message"]');

    if (!box) {
      if (type === "error") console.error(message);
      else console.log(message);
      return;
    }

    box.textContent = message || "";
    box.className = "";
    box.classList.add(type === "error" ? "message-error" : "message-success");
    box.style.display = message ? "" : "none";

    clearTimeout(showTopMessage._timer);
    showTopMessage._timer = setTimeout(function () {
      box.style.display = "none";
    }, 3500);
  }

  function absoluteUrl(path) {
    if (/^https?:\/\//i.test(path)) return path;
    return API_BASE.replace(/\/+$/, "") + "/" + String(path || "").replace(/^\/+/, "");
  }

  function errorMessage(err) {
    if (!err) return "Something went wrong.";
    if (typeof err === "string") return err;
    return err.message || "Something went wrong.";
  }

  function setText(selectors, value) {
    const list = Array.isArray(selectors) ? selectors : [selectors];
    for (let i = 0; i < list.length; i += 1) {
      const el = document.querySelector(list[i]);
      if (el) {
        el.textContent = value;
        return;
      }
    }
  }

  function $(selector, root) {
    return (root || document).querySelector(selector);
  }

  function $all(selector, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(selector));
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === "function") {
      return window.CSS.escape(value);
    }
    return String(value).replace(/"/g, '\\"');
  }
})();