/* havn-auth.js — CANONICAL + LOOP-SAFE BASELINE (2026-01-22)
   Goals:
   - Canonical host = havn.ie (no www). Prevents “token not found” loops.
   - Token key is ALWAYS localStorage.getItem("token")
   - apiFetch ALWAYS returns Response (never auto-json)
   - requireAuth() redirects ONLY on 401/403 (never on network/5xx)
*/

(function () {
  "use strict";

  const CANON_HOST = "havn.ie";
  const API_BASE = "https://api.havn.ie";
  const TOKEN_KEY = "token";

  function nowIso() {
    try { return new Date().toISOString(); } catch { return ""; }
  }

  function safeStorageGet(k) {
    try { return localStorage.getItem(k); } catch { return null; }
  }
  function safeStorageSet(k, v) {
    try { localStorage.setItem(k, v); } catch {}
  }
  function safeStorageDel(k) {
    try { localStorage.removeItem(k); } catch {}
  }

  function isBrowser() {
    return typeof window !== "undefined" && typeof document !== "undefined";
  }

  function canonicalizeHost() {
    if (!isBrowser()) return;
    try {
      const h = String(location.hostname || "").toLowerCase();
      if (h === "www." + CANON_HOST) {
        const url = "https://" + CANON_HOST + location.pathname + location.search + location.hash;
        location.replace(url);
      }
    } catch {}
  }

  // Run immediately (prevents cross-origin token loss loops)
  canonicalizeHost();

  function getToken() {
    return safeStorageGet(TOKEN_KEY);
  }

  function setToken(t) {
    if (!t) return;
    safeStorageSet(TOKEN_KEY, String(t));
  }

  function clearToken() {
    safeStorageDel(TOKEN_KEY);
  }

  function buildUrl(path) {
    const p = String(path || "");
    if (p.startsWith("http://") || p.startsWith("https://")) return p;
    if (!p.startsWith("/")) return API_BASE + "/" + p;
    return API_BASE + p;
  }

  // ✅ ALWAYS returns Response
  async function apiFetch(path, opts) {
    const token = getToken();
    const url = buildUrl(path);

    const options = Object.assign({ method: "GET" }, (opts || {}));
    options.headers = Object.assign({}, (options.headers || {}), {
      "Accept": "application/json",
    });

    // Attach bearer if present
    if (token) {
      options.headers["Authorization"] = "Bearer " + token;
    }

    // If sending JSON, ensure content-type
    if (options.body && typeof options.body === "object" && !(options.body instanceof FormData)) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(options.body);
    }

    return fetch(url, options);
  }

  function gotoLogin(nextUrl) {
    if (!isBrowser()) return;
    try {
      const next = nextUrl || (location.pathname + location.search);
      location.href = "/login.html?next=" + encodeURIComponent(next);
    } catch {
      location.href = "/login.html";
    }
  }

  // ✅ ONLY redirects on 401/403. Never on network/5xx.
  async function requireAuth(options) {
    const opts = options || {};
    const redirect = (opts.redirect !== false); // default true
    const token = getToken();

    if (!token) {
      if (redirect) gotoLogin();
      return { ok: false, reason: "NO_TOKEN" };
    }

    let res;
    try {
      res = await apiFetch("/api/auth/me", { method: "GET" });
    } catch (e) {
      // Network / CORS / transient error — DO NOT clear token, DO NOT redirect (prevents loops)
      return { ok: false, reason: "NETWORK", error: (e && e.message) ? e.message : String(e) };
    }

    if (res.status === 401 || res.status === 403) {
      // Auth truly invalid — safe to clear and redirect
      clearToken();
      if (redirect) gotoLogin();
      return { ok: false, reason: "UNAUTH", status: res.status };
    }

    if (!res.ok) {
      // 5xx/4xx other than 401/403 — keep token, do not redirect
      const txt = await res.text().catch(() => "");
      return { ok: false, reason: "BAD_STATUS", status: res.status, body: txt };
    }

    const data = await res.json().catch(() => null);
    const user = data && (data.user || data);
    return { ok: true, user: user || null };
  }

  async function login(email, password) {
    const payload = { email: String(email || "").trim(), password: String(password || "") };

    const res = await apiFetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload
    });

    const data = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        ok: false,
        status: res.status,
        message: (data && (data.message || data.error)) ? (data.message || data.error) : "Login failed"
      };
    }

    const token = data && (data.token || data.jwt);
    if (token) setToken(token);

    return { ok: true, user: data.user || null, token: token || null };
  }

  function logout() {
    clearToken();
    gotoLogin("/");
  }

  // Small helper for debug bars
  function authDebugSnapshot() {
    return {
      ts: nowIso(),
      host: (isBrowser() ? location.host : ""),
      canonical: CANON_HOST,
      api: API_BASE,
      hasToken: !!getToken(),
    };
  }

  window.HAVN_AUTH = {
    API_BASE,
    TOKEN_KEY,
    getToken,
    setToken,
    clearToken,
    apiFetch,      // returns Response
    requireAuth,   // loop-safe
    login,
    logout,
    authDebugSnapshot
  };
})();
