(function () {
  "use strict";

  const API_BASE = "https://api.havn.ie";
  const $ = (id) => document.getElementById(id);

  const grid = $("grid");
  const searchInput = $("search");
  const suggestBox = $("suggestBox");
  const notice = $("notice");
  const modeChip = $("modeChip");
  const countChip = $("countChip");
  const subText = $("subText");

  const params = new URLSearchParams(window.location.search);

  let MODE = cleanMode(params.get("mode") || "buy");
  let ALL_ITEMS = [];

  const HAVN_LOCATIONS = [
    { name: "Dublin", type: "County" },
    { name: "Dublin 1", type: "Area" },
    { name: "Dublin 2", type: "Area" },
    { name: "Dublin 4", type: "Area" },
    { name: "Dublin 6", type: "Area" },
    { name: "Dublin 8", type: "Area" },
    { name: "South Dublin", type: "Area" },
    { name: "North Dublin", type: "Area" },
    { name: "Cork", type: "County" },
    { name: "Galway", type: "County" },
    { name: "Kildare", type: "County" },
    { name: "Naas", type: "Town" },
    { name: "Maynooth", type: "Town" },
    { name: "Newbridge", type: "Town" },
    { name: "Celbridge", type: "Town" },
    { name: "Leixlip", type: "Town" },
    { name: "Meath", type: "County" },
    { name: "Navan", type: "Town" },
    { name: "Ashbourne", type: "Town" },
    { name: "Wicklow", type: "County" },
    { name: "Bray", type: "Town" },
    { name: "Greystones", type: "Town" },
    { name: "Limerick", type: "County" },
    { name: "Waterford", type: "County" },
    { name: "Kilkenny", type: "County" },
    { name: "Louth", type: "County" },
    { name: "Drogheda", type: "Town" },
    { name: "Dundalk", type: "Town" },
    { name: "Westmeath", type: "County" },
    { name: "Athlone", type: "Town" },
    { name: "Mullingar", type: "Town" }
  ];

  function cleanMode(value) {
    const m = String(value || "").trim().toLowerCase();
    if (m === "rent" || m === "share") return m;
    return "buy";
  }

  function modeToApi(value) {
    const m = cleanMode(value);
    if (m === "rent") return "RENT";
    if (m === "share") return "SHARE";
    return "BUY";
  }

  function esc(s) {
    return String(s || "").replace(/[&<>"']/g, function (m) {
      return {
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
      }[m];
    });
  }

  function norm(s) {
    return String(s || "")
      .toLowerCase()
      .replace(/[\u2019']/g, "'")
      .replace(/[^a-z0-9]+/g, " ")
      .replace(/\bco\b/g, " ")
      .replace(/\bcounty\b/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function money(n) {
    const num = Number(n);
    if (!Number.isFinite(num) || num <= 0) return "Price on request";
    return new Intl.NumberFormat("en-IE", {
      style: "currency",
      currency: "EUR",
      maximumFractionDigits: 0
    }).format(num);
  }

  function getFirstDefined() {
    for (let i = 0; i < arguments.length; i++) {
      const v = arguments[i];
      if (v !== undefined && v !== null && String(v).trim() !== "") return v;
    }
    return "";
  }

  function getThumb(p) {
    const imgs = p.photos || p.images || p.pictures || p.imageUrls || [];

    if (Array.isArray(imgs) && imgs.length) {
      const first = imgs[0];
      if (typeof first === "string") return first;
      if (first && typeof first === "object") {
        return first.url || first.secure_url || first.src || "";
      }
    }

    return p.cover || p.coverImage || p.image || "";
  }

  function isPublished(p) {
    const status = String(p.listingStatus || p.publicStatus || p.status || "").trim().toUpperCase();
    if (!status) return true;
    return status === "PUBLISHED";
  }

  function getSearchValue() {
    return searchInput ? searchInput.value.trim() : "";
  }

  function searchHaystack(p) {
    return norm([
      p.title,
      p.displayTitle,
      p.address,
      p.address1,
      p.address2,
      p.addressLine1,
      p.city,
      p.town,
      p.area,
      p.locality,
      p.county,
      p.eircode,
      p.description,
      p.propertyType,
      p.type
    ].filter(Boolean).join(" "));
  }

  function matchesSearch(p, query) {
    const q = norm(query);
    if (!q) return true;

    const h = searchHaystack(p);

    if (h.includes(q)) return true;

    const words = q.split(" ").filter(Boolean);
    if (!words.length) return true;

    return words.every(function (word) {
      return h.includes(word);
    });
  }

  function shortAddress(p) {
    const town = getFirstDefined(p.city, p.town, p.area, p.locality);
    const county = getFirstDefined(p.county);

    if (town && county) return town + ", Co. " + String(county).replace(/^Co\.\s*/i, "");
    if (town) return String(town);
    if (county) return "Co. " + String(county).replace(/^Co\.\s*/i, "");

    return getFirstDefined(p.address, p.address1, p.addressLine1, "Ireland");
  }

  function displayTitle(p) {
    const beds = getFirstDefined(p.bedrooms);
    const type = getFirstDefined(p.propertyType, p.type);

    if (beds && type) {
      return String(beds) + " Bed " + String(type).toLowerCase().replace(/^\w/, function (c) {
        return c.toUpperCase();
      });
    }

    return getFirstDefined(p.title, p.displayTitle, p.address, "Property");
  }

  function sortItems(items) {
    return items.slice().sort(function (a, b) {
      const at = Date.parse(a.publishedAt || a.createdAt || "");
      const bt = Date.parse(b.publishedAt || b.createdAt || "");
      return (Number.isFinite(bt) ? bt : 0) - (Number.isFinite(at) ? at : 0);
    });
  }

  async function fetchProperties() {
    const url = API_BASE + "/api/properties?limit=200&page=1&mode=" + encodeURIComponent(modeToApi(MODE));

    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      cache: "no-store"
    });

    const text = await res.text();
    let json = null;

    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }

    if (!res.ok) throw new Error(text || "Failed to load properties.");

    if (Array.isArray(json)) return json;
    if (json && Array.isArray(json.items)) return json.items;
    if (json && Array.isArray(json.properties)) return json.properties;
    if (json && Array.isArray(json.listings)) return json.listings;
    if (json && json.data && Array.isArray(json.data)) return json.data;
    if (json && json.data && Array.isArray(json.data.items)) return json.data.items;

    return [];
  }

  function buildCard(p) {
    const slug = getFirstDefined(p.slug, p.publicSlug, p.propertySlug, p.id);
    if (!slug) return "";

    const thumb = getThumb(p);
    const fallback = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(
      '<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="700"><rect width="1200" height="700" fill="#e5e7eb"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#64748b" font-size="44" font-family="Arial">HAVN.ie</text></svg>'
    );

    const title = displayTitle(p);
    const loc = shortAddress(p);

    const beds = getFirstDefined(p.bedrooms);
    const baths = getFirstDefined(p.bathrooms);
    const type = getFirstDefined(p.propertyType, p.type);

    return `
      <a class="prop-card" href="/property.html?slug=${encodeURIComponent(slug)}">
        <div style="position:relative;">
          <img class="prop-thumb" src="${esc(thumb || fallback)}" alt="${esc(title)}" loading="lazy">
        </div>
        <div class="prop-body">
          <div style="font-size:18px;font-weight:1000;letter-spacing:-0.02em;margin-bottom:4px;color:#0b1220;">
            ${esc(money(p.price))}
          </div>
          <h2 class="prop-title">${esc(title)}</h2>
          <div class="prop-meta">${esc(loc)}</div>
          <div class="prop-chips">
            ${beds ? `<span class="chip">${esc(String(beds))} bed</span>` : ""}
            ${baths ? `<span class="chip">${esc(String(baths))} bath</span>` : ""}
            ${type ? `<span class="chip">${esc(String(type).toLowerCase().replace(/^\w/, function (c) { return c.toUpperCase(); }))}</span>` : ""}
            <span class="chip">${esc(modeToApi(MODE))}</span>
          </div>
        </div>
      </a>
    `;
  }

  function updateUrl(q) {
    const url = new URL(window.location.href);
    url.searchParams.set("mode", MODE);

    if (q) url.searchParams.set("q", q);
    else url.searchParams.delete("q");

    window.history.replaceState({}, "", url.pathname + url.search + url.hash);
  }

  function render() {
    if (!grid) return;

    const q = getSearchValue();

    const filtered = sortItems(
      ALL_ITEMS
        .filter(isPublished)
        .filter(function (p) {
          return matchesSearch(p, q);
        })
    );

    if (countChip) countChip.textContent = "Count: " + filtered.length;

    if (subText) {
      subText.textContent = q
        ? "Published " + MODE + " listings matching: " + q
        : "Published " + MODE + " listings. Search town, county, area, Eircode or title.";
    }

    updateUrl(q);

    if (!filtered.length) {
      grid.innerHTML = "";
      if (notice) {
        notice.style.display = "block";
        notice.textContent = q ? "No published listings found for: " + q : "No published listings found.";
      }
      return;
    }

    if (notice) {
      notice.style.display = "none";
      notice.textContent = "";
    }

    grid.innerHTML = filtered.map(buildCard).join("");
  }

  function closeSuggestions() {
    if (!suggestBox) return;
    suggestBox.style.display = "none";
    suggestBox.innerHTML = "";
  }

  function openSuggestions(matches) {
    if (!suggestBox || !searchInput) return;

    if (!matches.length) {
      closeSuggestions();
      return;
    }

    suggestBox.innerHTML = matches.slice(0, 10).map(function (item) {
      return `
        <button class="suggestItem" type="button" data-name="${esc(item.name)}">
          <span>${esc(item.name)}</span>
          <span class="suggestType">${esc(item.type)}</span>
        </button>
      `;
    }).join("");

    suggestBox.style.display = "block";

    suggestBox.querySelectorAll(".suggestItem").forEach(function (btn) {
      btn.addEventListener("click", function () {
        searchInput.value = btn.getAttribute("data-name") || "";
        closeSuggestions();
        render();
      });
    });
  }

  function wireAutocomplete() {
    if (!searchInput || !suggestBox) return;

    searchInput.addEventListener("input", function () {
      const q = norm(searchInput.value);

      render();

      if (!q) {
        closeSuggestions();
        return;
      }

      const matches = HAVN_LOCATIONS.filter(function (item) {
        return norm(item.name).includes(q);
      });

      openSuggestions(matches);
    });

    searchInput.addEventListener("focus", function () {
      const q = norm(searchInput.value);
      if (!q) return;

      const matches = HAVN_LOCATIONS.filter(function (item) {
        return norm(item.name).includes(q);
      });

      openSuggestions(matches);
    });

    searchInput.addEventListener("search", function () {
      render();
      closeSuggestions();
    });

    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        e.preventDefault();
        render();
        closeSuggestions();
      }

      if (e.key === "Escape") {
        closeSuggestions();
      }
    });

    document.addEventListener("click", function (e) {
      if (!suggestBox.contains(e.target) && e.target !== searchInput) {
        closeSuggestions();
      }
    });
  }

  async function init() {
    const urlQ = (params.get("q") || "").trim();

    if (searchInput && urlQ) {
      searchInput.value = urlQ;
    }

    if (modeChip) modeChip.textContent = "Mode: " + MODE;

    wireAutocomplete();

    try {
      if (notice) {
        notice.style.display = "block";
        notice.textContent = "Loading listings…";
      }

      ALL_ITEMS = await fetchProperties();
      render();
    } catch (err) {
      if (grid) grid.innerHTML = "";
      if (countChip) countChip.textContent = "Count: —";
      if (notice) {
        notice.style.display = "block";
        notice.textContent = "Could not load listings.";
      }
      console.error(err);
    }
  }

  init();
})();